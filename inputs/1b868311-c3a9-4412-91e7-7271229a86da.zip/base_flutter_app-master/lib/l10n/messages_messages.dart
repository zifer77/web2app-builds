// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a messages locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// ignore_for_file: unnecessary_brace_in_string_interps

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

// ignore: unnecessary_new
final messages = new MessageLookup();

// ignore: unused_element
final _keepAnalysisHappy = Intl.defaultLocale;

// ignore: non_constant_identifier_names
typedef MessageIfAbsent(String message_str, List args);

class MessageLookup extends MessageLookupByLibrary {
  get localeName => 'messages';

  final messages = _notInlinedMessages(_notInlinedMessages);
  static _notInlinedMessages(_) => <String, Function> {
    "confirmPassword" : MessageLookupByLibrary.simpleMessage("confirm password"),
    "email" : MessageLookupByLibrary.simpleMessage("Email"),
    "feedbackHint" : MessageLookupByLibrary.simpleMessage("Let us know what you think"),
    "language" : MessageLookupByLibrary.simpleMessage("language"),
    "leaveFeedback" : MessageLookupByLibrary.simpleMessage("Leave Feedback"),
    "logIn" : MessageLookupByLibrary.simpleMessage("Log In"),
    "logOut" : MessageLookupByLibrary.simpleMessage("Log Out"),
    "loginCTA" : MessageLookupByLibrary.simpleMessage("Welcome Back."),
    "password" : MessageLookupByLibrary.simpleMessage("password"),
    "signUp" : MessageLookupByLibrary.simpleMessage("Sign Up"),
    "signupCTA" : MessageLookupByLibrary.simpleMessage("Create Account."),
    "username" : MessageLookupByLibrary.simpleMessage("Username"),
    "thanksForYourFeedback" : MessageLookupByLibrary.simpleMessage("Thank you for your feedback!"),
    "welcomeCTA" : MessageLookupByLibrary.simpleMessage("Hi, There.")
  };
}
