import 'package:flutter/material.dart';
import 'package:flutter_base_app/src/services/localizations/localizations.dart';
import 'package:flutter_base_app/src/widgets/language_picker.dart';
import 'package:flutter_base_app/src/widgets/onboarding_button.dart';
import 'package:flutter_base_app/src/widgets/layouts/FullScreenLayout.dart';
import 'package:flutter_base_app/src/services/routes.dart';
import 'package:flutter_base_app/src/services/navigator.dart';

class WelcomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final AppLocalizations localizations = AppLocalizations.of(context);

    final ThemeData theme = Theme.of(context);
    return Scaffold(
      body: FullScreenLayout(
        backgroundColor: theme.backgroundColor,
        child: Padding(
          padding: const EdgeInsets.all(30.0),
          child: Column(
            children: <Widget>[
              Text(
                localizations.welcomeCTA,
                style: theme.primaryTextTheme.display3,
              ),
              Expanded(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: <Widget>[
                    Row(
                      children: <Widget>[
                        Expanded(
                            child: OnboardingButton(
                          buttonText: localizations.logIn,
                          onPressed: () {
                            rootNavigationService
                                .navigateTo(FlutterAppRoutes.loginScreen);
                          },
                        )),
                      ],
                    ),
                    const SizedBox(height: 20),
                    Row(
                      children: <Widget>[
                        Expanded(
                            child: OnboardingButton(
                          buttonText: localizations.signUp,
                          isInverted: true,
                          onPressed: () {
                            rootNavigationService
                                .navigateTo(FlutterAppRoutes.signupScreen);
                          },
                        )),
                      ],
                    )
                  ],
                ),
              ),
              const LanguagePicker()
            ],
          ),
        ),
      ),
    );
  }
}
